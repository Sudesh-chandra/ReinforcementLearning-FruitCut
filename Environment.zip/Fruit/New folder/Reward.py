import cv2
import numpy as np
import os 
import pytesseract 
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

from Window import getScreenshot  # Assuming window.py has capture_screen()

previous_reward = 0  # Store previous reward to track increases
num=0
def extract_reward(img):
    global num
    """Extracts reward number from the given image using OCR."""
    # Save the original image
    save_path = os.path.join(os.path.dirname(__file__), "screenshot"+str(num)+".png")
    cv2.imwrite(save_path, img)

    # Define ROI (top-left corner where the number is located)
    x, y, w, h = 20, 50, 150, 100  # Adjust as needed
    roi = img[y:y+h, x:x+w]

    # Save cropped ROI
    roi_path = os.path.join(os.path.dirname(__file__), "cropped_"+str(num)+".png")
    cv2.imwrite(roi_path, roi)
    num = num+1

    # Convert to grayscale
    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)

    # Apply thresholding for better OCR accuracy
    _, thresh = cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY)

    # Use pytesseract to extract digits
    custom_config = r'--oem 3 --psm 6 -c tessedit_char_whitelist=0123456789'
    reward_str = pytesseract.image_to_string(thresh, config=custom_config).strip()
    try:
        reward = int(reward_str)
    except ValueError:
        reward = 0

    #print(reward)
    return reward
    
def track_reward():
    """Captures the screen and tracks reward updates."""
    global previous_reward

    screenshot = getScreenshot()
    if screenshot is None:
        print("Error: Could not capture screen.")
        return
    
    reward = extract_reward(screenshot)
    if reward > previous_reward:
        print(str(reward)+"\n")
    else:
        print(str(reward)+"\n")
    previous_reward = reward  # Update stored reward
    
    return

# Example Usage
#if __name__ == "__main__":
 #   while True:
  #      track_reward()
