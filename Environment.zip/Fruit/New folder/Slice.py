import pyautogui
from Reward import track_reward
from model import predict
from Locate import *

def slice(x1: float, y1: float, x2: float, y2: float):
    # Transform coords to work with mouse
    x1, y1 = gameToScreenCoord(x1, y1)
    x2, y2 = gameToScreenCoord(x2, y2)
    print([x1,y1,x2,y2])
    pyautogui.moveTo(x1, y1, _pause=False)
    pyautogui.mouseDown(_pause=False)
    #pyautogui.sleep(0.01)
    pyautogui.moveTo(x2, y2, 0.01, _pause=False)
    #pyautogui.sleep(0.01)
    #pyautogui.mouseUp(_pause=False)
    #pyautogui.sleep(0.01)
def sliceFruits(fruits: list, bombs: list):
    if (len(fruits) > 0):
        # Minimum distance required between a fruit and the bombs that can be sliced
        minFruitBombDistance = scaleComponent(100.0)
        fruitIndex = 0
        #for x in  fruits:
        #    print(x)
        #    print(" ")
        #print("\n")
        print(fruits)
        # Search for a safe fruit to slice
        while True:
            selectedFruit = fruits[fruitIndex]
            safeFruitFound = True

            # Check if the selected fruit is too close to any bombs
            for bomb in bombs:
                fruitBombDistance = distance(*selectedFruit[:2], *bomb[:2])

                if fruitBombDistance < minFruitBombDistance:
                    fruitIndex += 1
                    if fruitIndex >= len(fruits):
                        return
                    safeFruitFound = False
                    break

            if safeFruitFound:
                break

        sliceLength = 350.0
        sliceStart = ( selectedFruit[0] + sliceLength * 0.25, selectedFruit[1] + sliceLength * 0.25 )
        sliceEnd = ( selectedFruit[0] - sliceLength * 0.25, selectedFruit[1] - sliceLength * 0.25 )

        slicingArgs = (*sliceStart, *sliceEnd)
        slice(*slicingArgs)
        points = pointify(*slicingArgs)
        track_reward()
        if selectedFruit[3] != ( 210, 70, 60 ):
            # Discard points along the slice
            for point in points:
                Properties.discardedCoords[point] = time.time() #+ 1.0
        else:
            slice(*slicingArgs)
            track_reward()
