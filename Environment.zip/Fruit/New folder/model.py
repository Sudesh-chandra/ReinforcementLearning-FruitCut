import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
class Actor(nn.Module):
    def __init__(self, input_dim=9, output_dim=4):
        super(Actor, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, output_dim)
        )

    def forward(self, x):
        return self.model(x)
    
#2. Helper to preprocess fruit_location
def preprocess_fruit_location(fruit_location):
    x, y, velocity, dimensions, reward = fruit_location
    input_array = [x, y] + velocity + list(dimensions) + [reward]
    input_tensor = torch.tensor(input_array, dtype=torch.float32)
    return input_tensor

#3. Load the trained model 
loaded_actor = Actor(input_dim=9, output_dim=4)
loaded_actor.load_state_dict(torch.load(r"C:\Users\kvsud\Downloads\actor_model.pth"))
#loaded_actor.eval()  # Set to eval mode

#4. Testing the prediction function
'''
fruit_location = (576, 406, [155.0, 95.11, 20.11], (170, 100, 20), 20.0)
input_tensor = preprocess_fruit_location(fruit_location)
predicted_cut = loaded_actor(input_tensor).detach().numpy()
print(predicted_cut)
'''
#5. The callable predict function
def predict(fruit_location):
    input_tensor = preprocess_fruit_location(fruit_location)
    predicted_cut = loaded_actor(input_tensor).detach().numpy()
    return predicted_cut